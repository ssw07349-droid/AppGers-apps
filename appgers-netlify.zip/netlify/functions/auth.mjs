// AppGers: hisoblar (ro'yxatdan o'tish, kirish, profil) — Netlify Functions + Netlify Blobs
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api/auth" };

const J = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });

const hash = (p, salt) => crypto.pbkdf2Sync(p, salt, 100000, 32, "sha256").toString("hex");
const same = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

export default async (req) => {
  if (req.method !== "POST") return J({ error: "POST kerak" }, 405);
  let b;
  try { b = await req.json(); } catch { return J({ error: "Noto'g'ri so'rov." }, 400); }

  const a = String(b.a || "");
  const u = String(b.u || "").trim();
  const key = u.toLowerCase();
  if (!/^[\p{L}\p{N}_.@+\-]{3,64}$/u.test(u)) return J({ error: "Nom 3-24 belgi: harf, raqam, _ . -" }, 400);

  const users = getStore({ name: "users", consistency: "strong" });
  const fails = getStore({ name: "fails", consistency: "strong" });
  const rec = await users.get(key, { type: "json" });

  /* profil (nik va rasm) saqlash */
  if (a === "profile") {
    if (!rec || !same(rec.s, b.s || "")) return J({ error: "Ruxsat yo'q." }, 403);
    const n = String(b.n || "").slice(0, 24);
    const p = String(b.p || "");
    if (p && (!p.startsWith("data:image/") || p.length > 60000)) return J({ error: "Rasm juda katta." }, 413);
    rec.prof = { n, p };
    await users.setJSON(key, rec);
    return J({ ok: true });
  }

  if (a === "register") {
    if (rec) return J({ error: "Bu nom band." }, 409);
    const p = String(b.p || "");
    if (p.length < 6 || p.length > 200) return J({ error: "Parol kamida 6 belgi bo'lsin." }, 400);
    const salt = crypto.randomBytes(16).toString("hex");
    const nu = { n: u, salt, h: hash(p, salt), s: crypto.randomBytes(24).toString("hex"), prof: { n: "", p: "" } };
    await users.setJSON(key, nu);
    return J({ user: nu.n, secret: nu.s, profile: nu.prof });
  }

  if (a === "login") {
    if (!rec) return J({ error: "Bunday foydalanuvchi topilmadi." }, 400);
    const f = (await fails.get(key, { type: "json" })) || { c: 0, t: 0 };
    if (f.c >= 8 && Date.now() - f.t < 5 * 60 * 1000) return J({ error: "Juda ko'p urinish. 5 daqiqadan keyin qayta urining." }, 429);
    if (!same(hash(String(b.p || ""), rec.salt), rec.h)) {
      await fails.setJSON(key, { c: (Date.now() - f.t < 5 * 60 * 1000 ? f.c : 0) + 1, t: Date.now() });
      return J({ error: "Parol noto'g'ri." }, 401);
    }
    if (f.c) await fails.delete(key);
    return J({ user: rec.n, secret: rec.s, profile: rec.prof || { n: "", p: "" } });
  }

  return J({ error: "Noma'lum amal." }, 400);
};
