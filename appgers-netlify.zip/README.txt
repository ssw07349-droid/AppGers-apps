AppGers + hisoblar serveri (Netlify)

Fayllar:
  index.html                     - sayt
  netlify/functions/auth.mjs     - ro'yxatdan o'tish / kirish / profil (nik, rasm)
  package.json, netlify.toml     - Netlify sozlamalari

DIQQAT: app.netlify.com/drop (papkani sudrab tashlash) funksiyalarni joylamaydi.
Quyidagilardan birini ishlating:
  A) GitHub: papkani repoga yuklang -> Netlify -> Add new site -> Import from Git.
  B) CLI:   npm i -g netlify-cli ; netlify login ; netlify deploy --prod
